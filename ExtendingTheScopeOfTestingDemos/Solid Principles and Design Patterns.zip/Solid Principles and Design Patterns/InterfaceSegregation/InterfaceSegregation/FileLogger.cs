//using System;
//using System.IO;

//namespace InterfaceSegregation
//{
// STUB Class not needed because JustMock framework being used
//    public class FileLogger : ILogger
//    {
//        public void Handle(string message)
//        {
//            using (StreamWriter writer = new StreamWriter("c:\\Temp\\LogFile.txt", true))
//            {
//                writer.Write("{0}\n", message.ToString());
//            }
//        }
//    }
//}