﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InterfaceSegregation
{
    public class A_GoldCustomer : A_OldCustomer
    {
        public A_GoldCustomer(ILogger logger) : base(logger)
        {

        }

        public override decimal GetDiscountedPrice(decimal totalSales)
        {
            return totalSales - (totalSales * 10 / 100);
        }
    }
}
