﻿using InterfaceSegregation;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.JustMock;

namespace InterfaceSegregationTester
{

    [TestClass]
    public class CustomerTests
    {
        /// <summary>
        /// Now there is no confusion, we can create a list of “IDatabase” interface 
        /// and add the relevant classes to it. In case we make a mistake of adding 
        /// “B_Enquiry” class to the list compiler would complain as shown in the below code.
        /// </summary>
        [TestMethod]
        public void OldCustomerTestsSameAsBefore()
        {
            //Arrange
            List<ISale> customers = new List<ISale>();
            ILogger logger = Mock.Create<ILogger>();
            Mock.Arrange(() => logger.Handle(Arg.AnyString)).Occurs(2);

            customers.Add(new A_SilverCustomer(logger));
            customers.Add(new A_GoldCustomer(logger));

            //Act
            foreach (ISale o in customers)
            {
                o.AddSaleToDatabase("Shoes", 100.00M);
            }

            //Assert
            //Code that ensures logging has worked correctly
            Mock.Assert(logger);
        }

        /// <summary>
        /// Now there is no confusion, we can create a list of “IDatabase” interface 
        /// and add the relevant classes to it. In case we make a mistake of adding 
        /// “B_Enquiry” class to the list compiler would complain as shown in the below code.
        /// </summary>
        [TestMethod]
        public void NewCustomerTestsIncludeCallToRetrieveLoyaltyPointsMethod()
        {
            //Arrange
            List<ISaleV2> customers = new List<ISaleV2>();
            ILogger logger = Mock.Create<ILogger>();
            Mock.Arrange(() => logger.Handle(Arg.AnyString)).Occurs(2);

            customers.Add(new B_PlatinumCustomer(logger));
            customers.Add(new B_DiamondCustomer(logger));
            int totalLoyaltyPoints = 0;

            //Act
            foreach (ISaleV2 o in customers)
            {
                o.AddSaleToDatabase("Shoes", 100.00M);
                totalLoyaltyPoints += o.RetrieveLoyaltyPoints();
            }

            //Assert
            //Code that ensures logging has worked correctly
            Assert.AreEqual(235, totalLoyaltyPoints);
            Mock.Assert(logger);
        }

        /// <summary>
        /// Now there is no confusion, we can create a list of “IDisplay” interface 
        /// and add the relevant classes to it (including B_Enquiry).
        /// </summary>
        [TestMethod]
        public void GetDiscountsOldAndNewTogether()
        {
            //Arrange
            decimal totalSales = 200;
            decimal sumOfTotalSales = 0;
            List<IDiscount> customers = new List<IDiscount>();
            ILogger logger = Mock.Create<ILogger>();

            customers.Add(new A_SilverCustomer(logger));
            customers.Add(new A_GoldCustomer(logger));
            customers.Add(new B_PlatinumCustomer(logger));
            customers.Add(new B_DiamondCustomer(logger));
            customers.Add(new A_Enquiry(logger));

            //Act
            foreach (IDiscount o in customers)
            {
                sumOfTotalSales += o.GetDiscountedPrice(totalSales);
            }

            //Assert
            Assert.AreEqual(896, sumOfTotalSales);

        }
    }
}
