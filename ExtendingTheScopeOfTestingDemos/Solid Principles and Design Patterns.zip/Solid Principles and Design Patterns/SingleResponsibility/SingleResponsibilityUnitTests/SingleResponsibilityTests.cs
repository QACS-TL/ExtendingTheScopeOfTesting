﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SingleResponsibility;
using NSubstitute;
using Telerik.JustMock;

namespace SingleResponsibilityUnitTests
{
    //Note: The following methods are not really testing anything. They are designed to 
    //simply show what the client code would look like for the 3 scenarios
    
    [TestClass]
    public class SingleResponsibilityTests
    {
        [TestMethod]
        public void TestBadCustomer()
        {
            A_BadCustomer badCustomer = new A_BadCustomer();
            badCustomer.AddToMailingList("Mailing list details");
        }

        [TestMethod]
        public void TestBetterCustomer()
        {
            B_BetterCustomer betterCustomer = new B_BetterCustomer();
            betterCustomer.AddToMailingList("Mailing list details");
        }

        [TestMethod]
        public void TestBestCustomer()
        {
            ILogger logger = new FileLogger();
            C_BestCustomer bestCustomer = new C_BestCustomer(logger);
            bestCustomer.AddToMailingList("Mailing list details");
        }

        [TestMethod]
        public void TestBestCustomerUsingStub()
        {
            //Not a brilliant test because the Handle method in 
            //the StubLogger class is a void method so it's difficult
            //to prove the Handle method has been successfully invoked.
            ILogger logger = new StubLogger();
            C_BestCustomer bestCustomer = new C_BestCustomer(logger);
            bestCustomer.AddToMailingList("Mailing list details");
        }

        //Using a Mocking Framework allows you to create stubs 
        //but you can also use them to specify (and assert) expectations
        //such that a particular method is called a specified number of times.

        //Using the NSubstitute mocking framework
        [TestMethod]
        public void TestBestCustomerUsingNSubstitute()
        {

            //Arrange
            var logger = Substitute.For<ILogger>(); 
            string details = "Mailing list details";
            Exception ex = new Exception(details);

            //Act
            C_BestCustomer bestCustomer = new C_BestCustomer(logger);
            bestCustomer.AddToMailingList(details);

            //Assert
            logger.Received().Handle(ex.Message); 
        }

        //Same test but using Telerik's JustMock mocking framework
        [TestMethod]
        public void TestBestCustomerUsingJustmock()
        {
            //Arrange
            ILogger logger = Mock.Create<ILogger>();
            string details = "Mailing list details";
            Exception ex = new Exception(details);
            Mock.Arrange(() => logger.Handle(ex.Message)).Occurs(1);

            //Act
            C_BestCustomer bestCustomer = new C_BestCustomer(logger);
            bestCustomer.AddToMailingList(details);

            //Assert
            Mock.Assert(logger);
        }

    }
}
