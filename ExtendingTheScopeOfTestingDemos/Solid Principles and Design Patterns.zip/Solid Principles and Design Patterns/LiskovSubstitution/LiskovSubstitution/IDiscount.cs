public interface IDiscount {
	decimal GetDiscountedPrice(decimal TotalSales);
}