using LiskovSubstitution;
using System;
using System.IO;

public class FileLogger :ILogger
{
    public void Handle(string message)
    {
        using (StreamWriter writer = new StreamWriter("c:\\Temp\\Error.txt", true))
        {
            writer.Write("{0}\n", message.ToString());
        }
    }
}