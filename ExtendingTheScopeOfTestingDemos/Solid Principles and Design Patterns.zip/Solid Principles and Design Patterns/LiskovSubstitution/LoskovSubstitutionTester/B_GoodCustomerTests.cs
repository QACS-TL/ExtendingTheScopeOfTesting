﻿using LiskovSubstitution;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.JustMock;

namespace LoskovSubstitutionTester
{

    [TestClass]
    public class B_GoodCustomerTests
    {
        /// <summary>
        /// Now there is no confusion, we can create a list of “IDatabase” interface 
        /// and add the relevant classes to it. In case we make a mistake of adding 
        /// “B_Enquiry” class to the list compiler would complain as shown in the below code.
        /// </summary>
        [TestMethod]
        public void NoEnquiryProblemBecauseCodeWouldNotCompile()
        {
            //Arrange
            List<ISale> customers = new List<ISale>();
            FileLogger logger = new FileLogger();

            customers.Add(new B_SilverCustomer(logger));
            customers.Add(new B_GoldCustomer(logger));
            //The following line will now not compile:
            //customers.Add(new B_Enquiry(logger));

            //Act
            foreach (ISale o in customers)
            {
                o.AddSaleToDatabase("Shoes", 100.00M);
            }

            //Assert
            //Code that ensures logging has worked correctly

        }

        /// <summary>
        /// Now there is no confusion, we can create a list of “IDisplay” interface 
        /// and add the relevant classes to it (including B_Enquiry).
        /// </summary>
        [TestMethod]
        public void GetDiscounts()
        {
            //Arrange
            decimal price = 200;
            decimal sumOfDiscountedPrices = 0;
            List<IDiscount> customers = new List<IDiscount>();
            FileLogger logger = new FileLogger();

            customers.Add(new B_SilverCustomer(logger));
            customers.Add(new B_GoldCustomer(logger));
            customers.Add(new B_Enquiry(logger));

            //Act
            foreach (IDiscount o in customers)
            {
                sumOfDiscountedPrices += o.GetDiscountedPrice(price);
            }

            //Assert

            Assert.AreEqual(566.00M, sumOfDiscountedPrices);
        }

    }
}
