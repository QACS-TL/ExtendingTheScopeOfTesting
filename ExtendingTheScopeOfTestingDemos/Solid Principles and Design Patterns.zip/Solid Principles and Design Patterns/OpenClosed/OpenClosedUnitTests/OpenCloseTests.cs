﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenClosedPrinciple;

namespace OpenClosedUnitTests
{
    [TestClass]
    public class OpenCloseTests
    {
        [TestMethod]
        public void GoldBadCustomerTest()
        {
            A_BadCustomer badCustomer = new A_BadCustomer();
            badCustomer.CustomerType = CustomerType.Gold;
            double discountedPrice = badCustomer.GetDiscountedPrice(1000.00);

            Assert.AreEqual(900.00, discountedPrice);
        }

        [TestMethod]
        public void SilverBadCustomerTest()
        {
            A_BadCustomer badCustomer = new A_BadCustomer();
            badCustomer.CustomerType = CustomerType.Silver;
            double discountedPrice = badCustomer.GetDiscountedPrice(1000.00);

            Assert.AreEqual(950.00, discountedPrice);
        }

        [TestMethod]
        public void GoldGoodCustomerTest()
        {
            B_GoodCustomer goodCustomer = new GoldCustomer();
            double discountedPrice = goodCustomer.GetDiscountedPrice(1000.00);

            Assert.AreEqual(900.00, discountedPrice);
        }

        [TestMethod]
        public void SilverGoodCustomerTest()
        {
            B_GoodCustomer goodCustomer = new SilverCustomer();
            double discountedPrice = goodCustomer.GetDiscountedPrice(1000.00);

            Assert.AreEqual(950.00, discountedPrice);
        }

        [TestMethod]
        public void MixedGoodCustomersTest()
        {
            B_GoodCustomer customer1 = new SilverCustomer();
            B_GoodCustomer customer2 = new GoldCustomer();
            B_GoodCustomer customer3 = new GoldCustomer();
            B_GoodCustomer customer4 = new BronzeCustomer();

            List<B_GoodCustomer> customers = new List<B_GoodCustomer>();
            customers.Add(customer1);
            customers.Add(customer2);
            customers.Add(customer3);
            customers.Add(customer4);

            double totalDiscountedPrices = 0;
            double originalPrice = 1000.00;

            foreach (B_GoodCustomer customer in customers)
            {
                totalDiscountedPrices += customer.GetDiscountedPrice(originalPrice);
            }

            Assert.AreEqual(3730.00, totalDiscountedPrices);
        }
    }
}
