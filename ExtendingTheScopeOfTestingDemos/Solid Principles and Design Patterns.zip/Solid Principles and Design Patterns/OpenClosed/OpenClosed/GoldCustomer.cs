namespace OpenClosedPrinciple
{
    public class GoldCustomer : B_GoodCustomer {
        public override double GetDiscountedPrice(double totalSales)
        {
            return totalSales - 10 * totalSales / 100;
        }
    }
}