namespace OpenClosedPrinciple
{
    public class SilverCustomer : B_GoodCustomer {
        public override double GetDiscountedPrice(double TotalSales)
        {
            return TotalSales - 5 * TotalSales / 100;
        }
    }
}