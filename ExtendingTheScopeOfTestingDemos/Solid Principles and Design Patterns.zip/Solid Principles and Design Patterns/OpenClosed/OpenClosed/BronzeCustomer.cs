﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenClosedPrinciple
{
    public class BronzeCustomer : B_GoodCustomer
    {
        public override double GetDiscountedPrice(double totalSales)
        {
            return totalSales - 2 * totalSales / 100;
        }
    }
}
