namespace PondLife
{
	public interface IDuck {
        void Swim();
        void Waddle();
        void Fly();
        // contract says that getIsSwimming should be true if swim has been called.
        bool IsSwimming { get; } 
}
}