﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PondLife
{
    public class OrganicDuck:IDuck
    {
        private bool isSwimming = false;
        public bool IsSwimming
        {
            get
            {
                /* let outside world know if the duck is swimming */
                return isSwimming;
            }
        }

        public void Swim()
        {
            //do something to swim
            isSwimming = true;
        }

        public void Waddle()
        {
            //not swimming
            isSwimming = false;
        }

        public void Fly()
        {
            //not swimming
            isSwimming = false;
        }
    }
}
