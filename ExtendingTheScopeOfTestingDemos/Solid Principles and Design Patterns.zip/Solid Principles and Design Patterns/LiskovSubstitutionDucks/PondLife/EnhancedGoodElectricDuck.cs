﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PondLife
{
    public class EnhancedGoodElectricDuck: IDuck
    {
        private bool isTurnedOn = false;
        //Time has passed and new functionality added
        private bool isInflated = false;

        private bool isSwimming;
        public bool IsSwimming
        {
            get
            {
                return isSwimming;
            }
        }

        //New Functionality
        public void InflateDuck()
        {
            isInflated = true;
        }

        //New Functionality
        public void DeflateDuck()
        {
            isInflated = false;
        }

        public void TurnOn()
        {
            //New Functionality:
            //Can't turn duck on if not inflated
            if (isInflated)
            {
                isTurnedOn = true;
            }
            else
            {
                isTurnedOn = false;
            }
        }

        public void TurnOff()
        {
            isTurnedOn = false;
        }

        public void Swim()
        {
            this.TurnOn(); // will now NOT necessarily set isTurnedOn to true because the duck might not be inflated!

            //Possibly swimming when it shouldn't be because TurnOn may fail!!! 
            //What should we do?
            //ANS 1: Add (at top of this method) a call to inflateDuck because
            //when asked to swim a duck should just swim! 
            //ANS 2: Check to see if duck has successfully turned on and only set isSwimming to true
            //if it is
            //This is why this is a good design because it can cope with issues like this
            if (this.isTurnedOn)
                isSwimming = true;
            //swim logic  
        }

        public void Waddle()
        {
            this.TurnOn();

            isSwimming = false;
            //waddle logic  
        }

        public void Fly()
        {
            this.TurnOn();

            isSwimming = false;
            //fly logic  
        }
    }
}
