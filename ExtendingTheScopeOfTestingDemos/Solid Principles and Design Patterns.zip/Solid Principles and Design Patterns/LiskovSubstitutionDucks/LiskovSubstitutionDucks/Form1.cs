﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PondLife;

namespace LiskovSubstitutionDucks
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void MakeDuckSwim(IDuck duck)
        {
            //Kludge to make bad electric duck swim
            //Breaks the Open/Closed principle and would have to be implemented everywhere
            //if (duck is BadElectricDuck)
            //{
            //    ((BadElectricDuck)duck).TurnOn();
            //}
            duck.Swim();
            MessageBox.Show(string.Format("the {0} is{1}swimming", duck.GetType().Name, (duck.IsSwimming) ? " " : " not "));
        }

        private void btnOrganicDuck_Click(object sender, EventArgs e)
        {
            IDuck organicDuck = new OrganicDuck();
            MakeDuckSwim(organicDuck);

        }

        private void btnBadElectricDuck_Click(object sender, EventArgs e)
        {
            IDuck badElectricDuck = new BadElectricDuck();
            MakeDuckSwim(badElectricDuck);
        }

        private void btnGoodElectricDuck_Click(object sender, EventArgs e)
        {
            IDuck goodElectricDuck = new GoodElectricDuck();
            MakeDuckSwim(goodElectricDuck);
        }

        private void btnEnhancedGoodElectricDuck_Click(object sender, EventArgs e)
        {
            IDuck enhancedGoodElectricDuck = new EnhancedGoodElectricDuck();
            MakeDuckSwim(enhancedGoodElectricDuck);
        }
    }
}
