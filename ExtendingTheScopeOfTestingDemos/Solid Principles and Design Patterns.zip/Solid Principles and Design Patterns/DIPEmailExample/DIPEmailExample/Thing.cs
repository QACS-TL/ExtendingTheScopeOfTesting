﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIPMessagerExample
{
    public class Thing
    {
        private int count;

        public int Count {
            get { return count; }
            set { count = value; }
        }

        private int height;
        public int Height {
            get { return height; }
            set { height = value; }
        }
        private int width;
        public int Width {
            get { return width; }
            set { width = value; }
        }

        public Thing() 
        {
            MessageService = new BestEmail("A", "B");
        }

        public IMessageService MessageService { get; set; }

        //public Thing(int count):this(count, 100)
        //{

        //}

        //public Thing(int count, int height):this(count, height, 200)
        //{

        //}

        //public Thing(int count, int height, int width)
        //{
        //    this.count = count;
        //    this.height = height;
        //    this.width = width;
        //}


        public Thing(int count) 
        {
            this.count = count;
            height = 100;
            width = 200;
        }

        public Thing(int count, int height) : this(count)
        {
            this.height = height;
        }

        public Thing(int count, int height, int width) : this(count, height)
        {
            this.width = width;
        }
    }
}
