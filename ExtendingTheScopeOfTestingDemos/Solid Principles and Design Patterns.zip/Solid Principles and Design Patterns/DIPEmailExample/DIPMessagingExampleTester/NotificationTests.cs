﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DIPMessagerExample;
using Telerik.JustMock;

namespace DIPMessagingExampleTester
{
    [TestClass]
    public class NotificationTests
    {
        [TestMethod]
        public void BadNotificationTest()
        {
            string emailAddress = "Esme@OverThere.com";
            string emailMessage = "Hello from over here";
            BadNotification notification = new BadNotification(emailAddress, emailMessage);
            notification.SendNotification();
        }

        [TestMethod]
        public void BetterNotificationTest()
        {
            //Actually things are NOT much better. The
            //"BetterNotification" object is still restricted
            //to using only "Email" objects
            string emailAddress = "Esme@OverThere.com";
            string emailMessage = "Hello from over here";
            BetterEmail email = new BetterEmail(emailAddress, emailMessage);
            BetterNotification notification = new BetterNotification(email);
            notification.SendNotification();
        }

        [TestMethod]
        public void BestNotificationTest()
        {
            string emailAddress = "Esme@OverThere.com";
            string emailMessage = "Hello from over here";
            IMessageService emailMessageService = new BestEmail(emailAddress, emailMessage);

            string userName = "Ted Tester";
            string userPassword = "Pa$$w0rd";
            string msgRecipient = "07800757165";
            string msgSource = "07800757165";
            string msgText = "Hi there!";
            IMessageService smsMessageService = new BestSMS(userName, userPassword, msgRecipient, msgSource, msgText);

            //can use any kind of messaging system
            //as long as it implements IMessageService

            //Inject service into Notification object's constructor
            BestNotification notification = new BestNotification(emailMessageService);

            notification.SendNotification();

            //Inject alternative service into Notification object's constructor
            notification = new BestNotification(smsMessageService);
            notification.SendNotification();
        }


        [TestMethod]
        public void BestNotificationTestUsingJustMock()
        {
            //string emailAddress = "Esme@OverThere.com";
            //string emailMessage = "Hello from over here";
            IMessageService emailMessageService = Mock.Create<IMessageService>();
            Mock.Arrange(() => emailMessageService.SendMessage()).OccursOnce();

            //string userName = "Ted Tester";
            //string userPassword = "Pa$$w0rd";
            //string msgRecipient = "07800757165";
            //string msgSource = "07800757165";
            //string msgText = "Hi there!";
            IMessageService smsMessageService = Mock.Create<IMessageService>();
            Mock.Arrange(() => smsMessageService.SendMessage()).OccursOnce();

            //can use any kind of messaging system
            //as long as it implements IMessageService

            //Inject service into Notification object's constructor
            BestNotification notification = new BestNotification(emailMessageService);
            notification.SendNotification();

            //Inject alternative service into Notification object's constructor
            notification = new BestNotification(smsMessageService);
            notification.SendNotification();

            Mock.Assert(emailMessageService);
            Mock.Assert(smsMessageService);


            Thing thing = new Thing
            {
                Count = 1,
                Width = 200,
                MessageService = new BestSMS("X", "y", "Z", "y", "Z")
            };

            //thing.MessageService = new BestSMS("X", "y", "Z", "y", "Z");
        }
    }
}
