﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LSPRectangleSquare;

namespace LSPRectangleSquareTester
{
    //Liskov Substitution Principle

    [TestClass]
    public class LSPRectangleSquareTests
    {
        [TestMethod]
        public void RectangleAreaVerifier()
        {
            //Arrange
            Rectangle r1 = new Rectangle();
            Rectangle r2 = new Rectangle();
         
            //Act
            r1.Width = 5;
            r1.Height = 4;

            //Set width & height in reverse sequence
            r2.Height = 4; 
            r2.Width = 5;


            //Assert
            Assert.AreEqual(r1.Area, r2.Area);

        }

        [TestMethod]
        public void SquareAreaVerifier()
        {
            //Arrange
            Rectangle r1 = new Square(); 
            Rectangle r2 = new Square();

            //Act
            r1.Width = 5;
            r1.Height = 4;

            //Set width & height in reverse sequence
            r2.Height = 4;
            r2.Width = 5;

            //Assert

            //The test will fail. The LSP states that substituting an object
            //of a subclass should not change the behaviour, or the correctness, 
            //of the program. However, if we substitute squares for rectangles the 
            //comparison fails. 
            Assert.AreEqual(r1.Area, r2.Area);

        }

        [TestMethod]
        public void NotMuchBetterRectangleAreaVerifier()
        {
            //Arrange
            INotMuchBetterQuadrilateral r1 = new NotMuchBetterRectangle();
            INotMuchBetterQuadrilateral r2 = new NotMuchBetterRectangle();

            //Act
            r1.Width = 5;
            r1.Height = 4;

            //Set width & height in reverse sequence
            r2.Height = 4;
            r2.Width = 5;


            //Assert
            Assert.AreEqual(r1.Area, r2.Area);

        }

        [TestMethod]
        public void NotMuchBetterSquareAreaVerifier()
        {
            //Arrange
            INotMuchBetterQuadrilateral r1 = new NotMuchBetterSquare();
            INotMuchBetterQuadrilateral r2 = new NotMuchBetterSquare();

            //Act
            r1.Width = 5;
            r1.Height = 4;

            //Set width & height in reverse sequence
            r2.Height = 4;
            r2.Width = 5;

            //Assert

            //The test will still fail. The LSP states that substituting an object
            //of a subclass should not change the behaviour, or the correctness, 
            //of the program. However, if we substitute NotMuchBetterSquares for NotMuchBetterRectangles the 
            //comparison fails. 
            Assert.AreEqual(r1.Area, r2.Area);

        }

        [TestMethod]
        public void ALotBetterRectangleAreaVerifier()
        {
            //Arrange & Act
            IALotBetterQuadrilateral q1 = new ALotBetterRectangle(5, 4);

            //Set width & height in reverse sequence
            IALotBetterQuadrilateral q2 = new ALotBetterRectangle(4, 5);

            //Can't now directly set the width or height 
            //q1.Width = 5;
            //q1.Height = 4;

            //Set width & height in reverse sequence
            //q2.Height = 4;
            //q2.Width = 5;

            //Assert
            Assert.AreEqual(q1.Area, q2.Area);

        }

        [TestMethod]
        public void ALotBetterSquareAreaVerifier()
        {
            //Arrange & Act
            IALotBetterQuadrilateral q1 = new ALotBetterSquare(5);
            IALotBetterQuadrilateral q2 = new ALotBetterSquare(4);

            //create rectangles that are really squares
            IALotBetterQuadrilateral q3 = new ALotBetterRectangle(5, 5);
            IALotBetterQuadrilateral q4 = new ALotBetterRectangle(4, 4);

            //Act
            //Can't now directly set the width or height 
            //q1.Width = 5;
            //q1.Height = 4;

            //Set width & height in reverse sequence
            //q2.Height = 4;
            //q2.Width = 5;

            //Assert

            //The test will pass. The Liskov Substitution Principle tells us that 
            //inheritance relationships should be based upon the external behaviour of 
            //types and not on the characteristics of the real-world objects that they may 
            //represent. Although a square is a rectangle, the external behaviour of the 
            //two representations is incompatible, so inheritance is invalid. 
            //                                     ^^^^^^^^^^^^^^^^^^^^^^^^^
            Assert.AreEqual((q1.Area == 25), (q2.Area == 16));
            Assert.AreEqual(q3.Area, q1.Area);
            Assert.AreEqual(q4.Area, q2.Area);

        }

        
    }
}
