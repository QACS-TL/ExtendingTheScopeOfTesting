namespace LSPRectangleSquare
{
    public interface IALotBetterQuadrilateral
    {
        double Width
        {
            get;
        }

        double Height
        {
            get;
        }

        double Area
        {
            get;
        }
        
    }
}