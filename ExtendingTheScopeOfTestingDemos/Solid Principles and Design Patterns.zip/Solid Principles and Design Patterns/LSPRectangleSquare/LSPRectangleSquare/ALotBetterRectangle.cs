﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LSPRectangleSquare
{
    public class ALotBetterRectangle: IALotBetterQuadrilateral
    {
        private double width;
        private double height;        
        
        public ALotBetterRectangle(double width, double height)
        {
            this.width = width;
            this.height = height;
        }

        public virtual double Width
        {
            get { return width; }
            private set { width = value; }
        }

        public virtual double Height
        {
            get { return height; }
            private set { height = value; }
        }

        public double Area
        {
            get
            {
                return Width * Height;
            }
        }
        
    }
}
